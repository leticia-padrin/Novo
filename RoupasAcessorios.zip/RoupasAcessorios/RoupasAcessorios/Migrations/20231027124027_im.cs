﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RoupasAcessorios.Migrations
{
    /// <inheritdoc />
    public partial class im : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tbCategria",
                columns: table => new
                {
                    CategoriaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbCategria", x => x.CategoriaId);
                });

            migrationBuilder.CreateTable(
                name: "tbClientes",
                columns: table => new
                {
                    ClientesId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Endereco = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Telefone = table.Column<int>(type: "int", nullable: false),
                    Cpf = table.Column<int>(type: "int", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DataNascimento = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbClientes", x => x.ClientesId);
                });

            migrationBuilder.CreateTable(
                name: "tbCompras",
                columns: table => new
                {
                    CadastroCId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NumeroVendas = table.Column<int>(type: "int", nullable: false),
                    DataHora = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbCompras", x => x.CadastroCId);
                });

            migrationBuilder.CreateTable(
                name: "tbFornecedors",
                columns: table => new
                {
                    FornecedorId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Cnpj = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbFornecedors", x => x.FornecedorId);
                });

            migrationBuilder.CreateTable(
                name: "tbRelaProd",
                columns: table => new
                {
                    RelaProdId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Categoria = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbRelaProd", x => x.RelaProdId);
                });

            migrationBuilder.CreateTable(
                name: "tbTipoMov",
                columns: table => new
                {
                    TipoMovId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NotaFiscal = table.Column<int>(type: "int", nullable: false),
                    DataHora = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TipoMove = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbTipoMov", x => x.TipoMovId);
                });

            migrationBuilder.CreateTable(
                name: "tbVendas",
                columns: table => new
                {
                    CadastroVId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NumeroVendas = table.Column<int>(type: "int", nullable: false),
                    DataHora = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClientesId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbVendas", x => x.CadastroVId);
                    table.ForeignKey(
                        name: "FK_tbVendas_tbClientes_ClientesId",
                        column: x => x.ClientesId,
                        principalTable: "tbClientes",
                        principalColumn: "ClientesId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbProdutos",
                columns: table => new
                {
                    ProdutosId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nome = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Estoque = table.Column<int>(type: "int", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CategoriaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FornecedorId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbProdutos", x => x.ProdutosId);
                    table.ForeignKey(
                        name: "FK_tbProdutos_tbCategria_CategoriaId",
                        column: x => x.CategoriaId,
                        principalTable: "tbCategria",
                        principalColumn: "CategoriaId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbProdutos_tbFornecedors_FornecedorId",
                        column: x => x.FornecedorId,
                        principalTable: "tbFornecedors",
                        principalColumn: "FornecedorId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbItensCompras",
                columns: table => new
                {
                    ItensComprascsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProdutosId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    CadastroCId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbItensCompras", x => x.ItensComprascsId);
                    table.ForeignKey(
                        name: "FK_tbItensCompras_tbCompras_CadastroCId",
                        column: x => x.CadastroCId,
                        principalTable: "tbCompras",
                        principalColumn: "CadastroCId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbItensCompras_tbProdutos_ProdutosId",
                        column: x => x.ProdutosId,
                        principalTable: "tbProdutos",
                        principalColumn: "ProdutosId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "tbItensVendas",
                columns: table => new
                {
                    ItemVendasId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProdutosId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Preco = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    CadastroVId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tbItensVendas", x => x.ItemVendasId);
                    table.ForeignKey(
                        name: "FK_tbItensVendas_tbProdutos_ProdutosId",
                        column: x => x.ProdutosId,
                        principalTable: "tbProdutos",
                        principalColumn: "ProdutosId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_tbItensVendas_tbVendas_CadastroVId",
                        column: x => x.CadastroVId,
                        principalTable: "tbVendas",
                        principalColumn: "CadastroVId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tbItensCompras_CadastroCId",
                table: "tbItensCompras",
                column: "CadastroCId");

            migrationBuilder.CreateIndex(
                name: "IX_tbItensCompras_ProdutosId",
                table: "tbItensCompras",
                column: "ProdutosId");

            migrationBuilder.CreateIndex(
                name: "IX_tbItensVendas_CadastroVId",
                table: "tbItensVendas",
                column: "CadastroVId");

            migrationBuilder.CreateIndex(
                name: "IX_tbItensVendas_ProdutosId",
                table: "tbItensVendas",
                column: "ProdutosId");

            migrationBuilder.CreateIndex(
                name: "IX_tbProdutos_CategoriaId",
                table: "tbProdutos",
                column: "CategoriaId");

            migrationBuilder.CreateIndex(
                name: "IX_tbProdutos_FornecedorId",
                table: "tbProdutos",
                column: "FornecedorId");

            migrationBuilder.CreateIndex(
                name: "IX_tbVendas_ClientesId",
                table: "tbVendas",
                column: "ClientesId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tbItensCompras");

            migrationBuilder.DropTable(
                name: "tbItensVendas");

            migrationBuilder.DropTable(
                name: "tbRelaProd");

            migrationBuilder.DropTable(
                name: "tbTipoMov");

            migrationBuilder.DropTable(
                name: "tbCompras");

            migrationBuilder.DropTable(
                name: "tbProdutos");

            migrationBuilder.DropTable(
                name: "tbVendas");

            migrationBuilder.DropTable(
                name: "tbCategria");

            migrationBuilder.DropTable(
                name: "tbFornecedors");

            migrationBuilder.DropTable(
                name: "tbClientes");
        }
    }
}
