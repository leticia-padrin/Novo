﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RoupasAcessorios.Migrations
{
    /// <inheritdoc />
    public partial class inicial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "RelatMov",
                columns: table => new
                {
                    RelatMovId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NotaFiscal = table.Column<int>(type: "int", nullable: false),
                    DataHora = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Quantidade = table.Column<int>(type: "int", nullable: false),
                    TipoMov = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProdutosId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ProdutoNome = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RelatMov", x => x.RelatMovId);
                    table.ForeignKey(
                        name: "FK_RelatMov_tbProdutos_ProdutosId",
                        column: x => x.ProdutosId,
                        principalTable: "tbProdutos",
                        principalColumn: "ProdutosId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RelatMov_ProdutosId",
                table: "RelatMov",
                column: "ProdutosId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RelatMov");
        }
    }
}
