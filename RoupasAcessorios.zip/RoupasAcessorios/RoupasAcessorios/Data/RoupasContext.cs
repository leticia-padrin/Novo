﻿using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Models;

namespace RoupasAcessorios.Data
{
    public class RoupasContext : DbContext
    {
        public RoupasContext(DbContextOptions options) : base(options) { }

        public DbSet<Clientes> Clientes { get; set; }
        public DbSet<Fornecedor> Fornecedores { get; set; }
        public DbSet<Categoria> Categoria { get; set; }
        public DbSet<Produtos> Produtos { get; set; }
        public DbSet<CadastroV> CadastroV { get; set; }
        public DbSet<CadastroC> CadastroC { get; set; }
        public DbSet<ItensComprascs> ItensComprascs { get; set; }
        public DbSet<ItemVendas> ItemVendas { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Clientes>().ToTable("tbClientes");
            modelBuilder.Entity<Fornecedor>().ToTable("tbFornecedors");
            modelBuilder.Entity<Categoria>().ToTable("tbCategria");
            modelBuilder.Entity<Produtos>().ToTable("tbProdutos");

            modelBuilder.Entity<CadastroV>().ToTable("tbVendas");
            modelBuilder.Entity<CadastroC>().ToTable("tbCompras");

            modelBuilder.Entity<ItensComprascs>().ToTable("tbItensCompras");
            modelBuilder.Entity<ItemVendas>().ToTable("tbItensVendas");


            modelBuilder.Entity<TipoMov>().ToTable("tbMovimentacao");
            modelBuilder.Entity<RelaProd>().ToTable("tbRelaProd");
            modelBuilder.Entity<TipoMov>().ToTable("tbTipoMov");
        }


        public DbSet<RoupasAcessorios.Models.TipoMov> TipoMov { get; set; } = default!;


        public DbSet<RoupasAcessorios.Models.RelaProd> RelaProd { get; set; } = default!;


        public DbSet<RoupasAcessorios.Models.RelatMov> RelatMov { get; set; } = default!;
    }
}
