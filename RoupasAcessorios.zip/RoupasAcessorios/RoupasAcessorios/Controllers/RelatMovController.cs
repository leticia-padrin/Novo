﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Data;
using RoupasAcessorios.Models;
using System.Data;

namespace RoupasAcessorios.Controllers
{
    [Authorize(Roles = "Admin, Gerente")]
    public class RelatMovController : Controller
    {
        private readonly RoupasContext _context;

        public RelatMovController(RoupasContext context)
        {
            _context = context;
        }
        public IActionResult RelMov()
        {
            var dbItensVendas = _context.ItemVendas.Include(v => v.CadastroV).Include(p => p.Produtos);
            var dbItensCompras = _context.ItensComprascs;
            var dbProdutos = _context.Produtos.Include(p => p.Fornecedor);

            List<RelatMov> listaMovimentacao = new List<RelatMov>();

            foreach (ItemVendas item in dbItensVendas)
            {
                RelatMov modelo = new RelatMov();

                modelo.TipoMov = "VENDA";
                modelo.Quantidade = item.Quantidade;
                modelo.ProdutosId = item.ProdutosId;
                modelo.DataHora = item.CadastroV.DataHora;
                modelo.ProdutoNome = item.Produtos.Nome;

                listaMovimentacao.Add(modelo);
            }

            foreach (ItensComprascs item in dbItensCompras)
            {
                RelatMov modelo = new RelatMov();

                modelo.TipoMov = "COMPRA";
                modelo.Quantidade = item.Quantidade;
                modelo.ProdutosId = item.ProdutosId;
                modelo.DataHora = item.CadastroC.DataHora;
                modelo.ProdutoNome = item.Produtos.Nome;

                listaMovimentacao.Add(modelo);
            }


            return View(listaMovimentacao);
        }
    }
}
