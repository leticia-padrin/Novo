﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Data;
using System.Data;

namespace RoupasAcessorios.Controllers
{
    [Authorize(Roles = "Admin, Gerente")]
    public class RelatProdController : Controller
    {
        private readonly RoupasContext _context;

        public RelatProdController(RoupasContext context)
        {
            _context = context;
        }
        public IActionResult RelProd()
        {
            var RoupasContext = _context.Produtos.Include(p => p.categoria).Include(p => p.Fornecedor);  
            return View(RoupasContext);
        }
    }
}
