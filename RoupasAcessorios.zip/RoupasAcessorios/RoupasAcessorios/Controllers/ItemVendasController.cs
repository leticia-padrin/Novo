﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Data;
using RoupasAcessorios.Models;

namespace RoupasAcessorios.Controllers
{
    public class ItemVendasController : Controller
    {
        private readonly RoupasContext _context;

        public ItemVendasController(RoupasContext context)
        {
            _context = context;
        }

        // GET: ItemVendas
        public async Task<IActionResult> Index()
        {
            var roupasContext = _context.ItemVendas.Include(i => i.CadastroV).Include(i => i.Produtos);
            return View(await roupasContext.ToListAsync());
        }

        // GET: ItemVendas/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.ItemVendas == null)
            {
                return NotFound();
            }

            var itemVendas = await _context.ItemVendas
                .Include(i => i.CadastroV)
                .Include(i => i.Produtos)
                .FirstOrDefaultAsync(m => m.ItemVendasId == id);
            if (itemVendas == null)
            {
                return NotFound();
            }

            return View(itemVendas);
        }

        // GET: ItemVendas/Create
        public IActionResult Create()
        {
            ViewData["CadastroVId"] = new SelectList(_context.CadastroV, "CadastroVId", "CadastroVId");
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId");
            return View();
        }

        // POST: ItemVendas/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ItemVendasId,ProdutosId,Preco,Quantidade,CadastroVId")] ItemVendas itemVendas)
        {
            if (ModelState.IsValid)
            {
                itemVendas.ItemVendasId = Guid.NewGuid();
                _context.Add(itemVendas);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CadastroVId"] = new SelectList(_context.CadastroV, "CadastroVId", "CadastroVId", itemVendas.CadastroVId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itemVendas.ProdutosId);
            return View(itemVendas);
        }

        // GET: ItemVendas/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.ItemVendas == null)
            {
                return NotFound();
            }

            var itemVendas = await _context.ItemVendas.FindAsync(id);
            if (itemVendas == null)
            {
                return NotFound();
            }
            ViewData["CadastroVId"] = new SelectList(_context.CadastroV, "CadastroVId", "CadastroVId", itemVendas.CadastroVId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itemVendas.ProdutosId);
            return View(itemVendas);
        }

        // POST: ItemVendas/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("ItemVendasId,ProdutosId,Preco,Quantidade,CadastroVId")] ItemVendas itemVendas)
        {
            if (id != itemVendas.ItemVendasId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(itemVendas);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ItemVendasExists(itemVendas.ItemVendasId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CadastroVId"] = new SelectList(_context.CadastroV, "CadastroVId", "CadastroVId", itemVendas.CadastroVId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itemVendas.ProdutosId);
            return View(itemVendas);
        }

        // GET: ItemVendas/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.ItemVendas == null)
            {
                return NotFound();
            }

            var itemVendas = await _context.ItemVendas
                .Include(i => i.CadastroV)
                .Include(i => i.Produtos)
                .FirstOrDefaultAsync(m => m.ItemVendasId == id);
            if (itemVendas == null)
            {
                return NotFound();
            }

            return View(itemVendas);
        }

        // POST: ItemVendas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.ItemVendas == null)
            {
                return Problem("Entity set 'RoupasContext.ItemVendas'  is null.");
            }
            var itemVendas = await _context.ItemVendas.FindAsync(id);
            if (itemVendas != null)
            {
                _context.ItemVendas.Remove(itemVendas);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ItemVendasExists(Guid id)
        {
          return (_context.ItemVendas?.Any(e => e.ItemVendasId == id)).GetValueOrDefault();
        }
    }
}
