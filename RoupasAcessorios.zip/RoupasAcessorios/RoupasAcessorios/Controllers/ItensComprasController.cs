﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Data;
using RoupasAcessorios.Models;

namespace RoupasAcessorios.Controllers
{
    public class ItensComprasController : Controller
    {
        private readonly RoupasContext _context;

        public ItensComprasController(RoupasContext context)
        {
            _context = context;
        }

        // GET: ItensCompras
        public async Task<IActionResult> Index()
        {
            var roupasContext = _context.ItensComprascs.Include(i => i.CadastroC).Include(i => i.Produtos);
            return View(await roupasContext.ToListAsync());
        }

        // GET: ItensCompras/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.ItensComprascs == null)
            {
                return NotFound();
            }

            var itensComprascs = await _context.ItensComprascs
                .Include(i => i.CadastroC)
                .Include(i => i.Produtos)
                .FirstOrDefaultAsync(m => m.ItensComprascsId == id);
            if (itensComprascs == null)
            {
                return NotFound();
            }

            return View(itensComprascs);
        }

        // GET: ItensCompras/Create
        public IActionResult Create()
        {
            ViewData["CadastroCId"] = new SelectList(_context.CadastroC, "CadastroCId", "CadastroCId");
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId");
            return View();
        }

        // POST: ItensCompras/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ItensComprascsId,ProdutosId,Preco,Quantidade,CadastroCId")] ItensComprascs itensComprascs)
        {
            if (ModelState.IsValid)
            {
                itensComprascs.ItensComprascsId = Guid.NewGuid();
                _context.Add(itensComprascs);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CadastroCId"] = new SelectList(_context.CadastroC, "CadastroCId", "CadastroCId", itensComprascs.CadastroCId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itensComprascs.ProdutosId);
            return View(itensComprascs);
        }

        // GET: ItensCompras/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.ItensComprascs == null)
            {
                return NotFound();
            }

            var itensComprascs = await _context.ItensComprascs.FindAsync(id);
            if (itensComprascs == null)
            {
                return NotFound();
            }
            ViewData["CadastroCId"] = new SelectList(_context.CadastroC, "CadastroCId", "CadastroCId", itensComprascs.CadastroCId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itensComprascs.ProdutosId);
            return View(itensComprascs);
        }

        // POST: ItensCompras/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("ItensComprascsId,ProdutosId,Preco,Quantidade,CadastroCId")] ItensComprascs itensComprascs)
        {
            if (id != itensComprascs.ItensComprascsId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(itensComprascs);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ItensComprascsExists(itensComprascs.ItensComprascsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CadastroCId"] = new SelectList(_context.CadastroC, "CadastroCId", "CadastroCId", itensComprascs.CadastroCId);
            ViewData["ProdutosId"] = new SelectList(_context.Produtos, "ProdutosId", "ProdutosId", itensComprascs.ProdutosId);
            return View(itensComprascs);
        }

        // GET: ItensCompras/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.ItensComprascs == null)
            {
                return NotFound();
            }

            var itensComprascs = await _context.ItensComprascs
                .Include(i => i.CadastroC)
                .Include(i => i.Produtos)
                .FirstOrDefaultAsync(m => m.ItensComprascsId == id);
            if (itensComprascs == null)
            {
                return NotFound();
            }

            return View(itensComprascs);
        }

        // POST: ItensCompras/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.ItensComprascs == null)
            {
                return Problem("Entity set 'RoupasContext.ItensComprascs'  is null.");
            }
            var itensComprascs = await _context.ItensComprascs.FindAsync(id);
            if (itensComprascs != null)
            {
                _context.ItensComprascs.Remove(itensComprascs);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ItensComprascsExists(Guid id)
        {
          return (_context.ItensComprascs?.Any(e => e.ItensComprascsId == id)).GetValueOrDefault();
        }
    }
}
