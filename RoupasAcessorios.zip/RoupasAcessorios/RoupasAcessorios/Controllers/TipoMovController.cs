﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Data;
using RoupasAcessorios.Models;

namespace RoupasAcessorios.Controllers
{
    [Authorize(Roles = "Admin, Gerente")]

    public class TipoMovController : Controller
    {
        private readonly RoupasContext _context;

        public TipoMovController(RoupasContext context)
        {
            _context = context;
        }

        // GET: TipoMov
        public async Task<IActionResult> Index()
        {
              return _context.TipoMov != null ? 
                          View(await _context.TipoMov.ToListAsync()) :
                          Problem("Entity set 'RoupasContext.TipoMov'  is null.");
        }

        // GET: TipoMov/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.TipoMov == null)
            {
                return NotFound();
            }

            var tipoMov = await _context.TipoMov
                .FirstOrDefaultAsync(m => m.TipoMovId == id);
            if (tipoMov == null)
            {
                return NotFound();
            }

            return View(tipoMov);
        }

        // GET: TipoMov/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TipoMov/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("TipoMovId,NotaFiscal,DataHora,TipoMove")] TipoMov tipoMov)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tipoMov);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tipoMov);
        }

        // GET: TipoMov/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.TipoMov == null)
            {
                return NotFound();
            }

            var tipoMov = await _context.TipoMov.FindAsync(id);
            if (tipoMov == null)
            {
                return NotFound();
            }
            return View(tipoMov);
        }

        // POST: TipoMov/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("TipoMovId,NotaFiscal,DataHora,TipoMove")] TipoMov tipoMov)
        {
            if (id != tipoMov.TipoMovId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tipoMov);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TipoMovExists(tipoMov.TipoMovId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tipoMov);
        }

        // GET: TipoMov/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.TipoMov == null)
            {
                return NotFound();
            }

            var tipoMov = await _context.TipoMov
                .FirstOrDefaultAsync(m => m.TipoMovId == id);
            if (tipoMov == null)
            {
                return NotFound();
            }

            return View(tipoMov);
        }

        // POST: TipoMov/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.TipoMov == null)
            {
                return Problem("Entity set 'RoupasContext.TipoMov'  is null.");
            }
            var tipoMov = await _context.TipoMov.FindAsync(id);
            if (tipoMov != null)
            {
                _context.TipoMov.Remove(tipoMov);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TipoMovExists(int id)
        {
          return (_context.TipoMov?.Any(e => e.TipoMovId == id)).GetValueOrDefault();
        }
    }
}
