﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Data;
using RoupasAcessorios.Models;

namespace RoupasAcessorios.Controllers
{
    [Authorize(Roles = "Admin, Operador")]
    public class CadastroVController : Controller
    {
        private readonly RoupasContext _context;

        public CadastroVController(RoupasContext context)
        {
            _context = context;
        }

        // GET: CadastroV
        public async Task<IActionResult> Index()
        {
            var roupasContext = _context.CadastroV.Include(c => c.Clientes);
            return View(await roupasContext.ToListAsync());
        }

        // GET: CadastroV/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.CadastroV == null)
            {
                return NotFound();
            }

            var cadastroV = await _context.CadastroV
                .Include(c => c.Clientes)
                .FirstOrDefaultAsync(m => m.CadastroVId == id);
            if (cadastroV == null)
            {
                return NotFound();
            }

            return View(cadastroV);
        }

        // GET: CadastroV/Create
        public IActionResult Create()
        {
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "Nome");
            return View();
        }

        // POST: CadastroV/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CadastroVId,NumeroVendas,DataHora,ClientesId")] CadastroV cadastroV)
        {
            if (ModelState.IsValid)
            {
                cadastroV.CadastroVId = Guid.NewGuid();
                _context.Add(cadastroV);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "Nome", cadastroV.ClientesId);
            return View(cadastroV);
        }

        // GET: CadastroV/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.CadastroV == null)
            {
                return NotFound();
            }

            var cadastroV = await _context.CadastroV.FindAsync(id);
            if (cadastroV == null)
            {
                return NotFound();
            }
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "Nome", cadastroV.ClientesId);
            return View(cadastroV);
        }

        // POST: CadastroV/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("CadastroVId,NumeroVendas,DataHora,ClientesId")] CadastroV cadastroV)
        {
            if (id != cadastroV.CadastroVId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cadastroV);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CadastroVExists(cadastroV.CadastroVId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClientesId"] = new SelectList(_context.Clientes, "ClientesId", "Nome", cadastroV.ClientesId);
            return View(cadastroV);
        }

        // GET: CadastroV/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.CadastroV == null)
            {
                return NotFound();
            }

            var cadastroV = await _context.CadastroV
                .Include(c => c.Clientes)
                .FirstOrDefaultAsync(m => m.CadastroVId == id);
            if (cadastroV == null)
            {
                return NotFound();
            }

            return View(cadastroV);
        }

        // POST: CadastroV/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.CadastroV == null)
            {
                return Problem("Entity set 'RoupasContext.CadastroV'  is null.");
            }
            var cadastroV = await _context.CadastroV.FindAsync(id);
            if (cadastroV != null)
            {
                _context.CadastroV.Remove(cadastroV);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CadastroVExists(Guid id)
        {
          return (_context.CadastroV?.Any(e => e.CadastroVId == id)).GetValueOrDefault();
        }
    }
}
