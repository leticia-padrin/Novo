﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RoupasAcessorios.Data;
using RoupasAcessorios.Models;

namespace RoupasAcessorios.Controllers
{
    [Authorize(Roles = "Admin, Operador")]
    public class CadastroCController : Controller
    {
        private readonly RoupasContext _context;

        public CadastroCController(RoupasContext context)
        {
            _context = context;
        }

        // GET: CadastroC
        public async Task<IActionResult> Index()
        {
              return _context.CadastroC != null ? 
                          View(await _context.CadastroC.ToListAsync()) :
                          Problem("Entity set 'RoupasContext.CadastroC'  is null.");
        }

        // GET: CadastroC/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.CadastroC == null)
            {
                return NotFound();
            }

            var cadastroC = await _context.CadastroC
                .FirstOrDefaultAsync(m => m.CadastroCId == id);
            if (cadastroC == null)
            {
                return NotFound();
            }

            return View(cadastroC);
        }

        // GET: CadastroC/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: CadastroC/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CadastroCId,NumeroVendas,DataHora,Quantidade,Preco")] CadastroC cadastroC)
        {
            if (ModelState.IsValid)
            {
                cadastroC.CadastroCId = Guid.NewGuid();
                _context.Add(cadastroC);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(cadastroC);
        }

        // GET: CadastroC/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.CadastroC == null)
            {
                return NotFound();
            }

            var cadastroC = await _context.CadastroC.FindAsync(id);
            if (cadastroC == null)
            {
                return NotFound();
            }
            return View(cadastroC);
        }

        // POST: CadastroC/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("CadastroCId,NumeroVendas,DataHora,Quantidade,Preco")] CadastroC cadastroC)
        {
            if (id != cadastroC.CadastroCId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(cadastroC);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CadastroCExists(cadastroC.CadastroCId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(cadastroC);
        }

        // GET: CadastroC/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.CadastroC == null)
            {
                return NotFound();
            }

            var cadastroC = await _context.CadastroC
                .FirstOrDefaultAsync(m => m.CadastroCId == id);
            if (cadastroC == null)
            {
                return NotFound();
            }

            return View(cadastroC);
        }

        // POST: CadastroC/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.CadastroC == null)
            {
                return Problem("Entity set 'RoupasContext.CadastroC'  is null.");
            }
            var cadastroC = await _context.CadastroC.FindAsync(id);
            if (cadastroC != null)
            {
                _context.CadastroC.Remove(cadastroC);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CadastroCExists(Guid id)
        {
          return (_context.CadastroC?.Any(e => e.CadastroCId == id)).GetValueOrDefault();
        }
    }
}
