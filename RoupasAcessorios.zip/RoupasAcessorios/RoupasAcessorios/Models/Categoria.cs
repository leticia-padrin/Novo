﻿using System.ComponentModel;

namespace RoupasAcessorios.Models
{
    public class Categoria
    {
        public Guid CategoriaId { get; set; }
        [DisplayName("Categoria do Produto")]
        public string Nome { get; set; }
    }
}
