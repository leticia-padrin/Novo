﻿using System.ComponentModel;

namespace RoupasAcessorios.Models
{
    public class CadastroV
    {
        public Guid CadastroVId { get; set; }
        
        [DisplayName("Número Nota de Venda")]
        public int NumeroVendas { get; set; }
 
        [DisplayName("Data e Hora")]
        public DateTime DataHora { get; set; }
       
        public Guid ClientesId { get; set; }
        public Clientes? Clientes { get; set; }

    }
}
