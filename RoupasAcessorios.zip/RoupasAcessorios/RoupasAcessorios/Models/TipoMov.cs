﻿using System.ComponentModel;

namespace RoupasAcessorios.Models
{
    public class TipoMov
    {
        public int TipoMovId { get; set; }
        [DisplayName("Nota Fiscal")]
        public int NotaFiscal { get; set; }
        [DisplayName("Data e Hora")]
        public DateTime DataHora { get; set; }
        [DisplayName("Tipo de Movimentação")]
        public string TipoMove { get; set; }

    }
}
