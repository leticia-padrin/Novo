﻿namespace RoupasAcessorios.Models
{
    public class ItemVendas
    {
        public Guid  ItemVendasId { get; set; }
        public Guid ProdutosId { get; set; }
        public Produtos? Produtos { get; set; }
        public decimal Preco { get; set; } 
        public int Quantidade { get; set; }
        public Guid CadastroVId { get; set; }
        public CadastroV? CadastroV { get; set; }
    }
}
