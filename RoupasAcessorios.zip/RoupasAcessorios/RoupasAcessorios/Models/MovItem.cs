﻿namespace RoupasAcessorios.Models
{
    public class MovItem
    {
        public Guid MovItemId { get; set; }
        public Guid ProdutosId { get; set; }
        public Produtos? Produtos { get; set; }
        public decimal Preco { get; set; }
        public int Quantidade { get; set; }
        public Guid TipoMovId { get; set; }
        public TipoMov? TipoMov { get; set; }
    }
}
