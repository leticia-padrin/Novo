﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel;

namespace RoupasAcessorios.Models
{
    public class Clientes
    {
        public Guid ClientesId { get; set; }
        public string Nome { get; set; }
        [DisplayName("Endereço")]
        public string Endereco { get; set; }
        public int Telefone { get; set; }
        [DisplayName("CPF")]
        public int Cpf { get; set; }
        public string Email { get; set; }
        [DisplayName("Data de Nascimento")]
        public DateTime DataNascimento { get; set; } 

        public IEnumerable<CadastroV>? Vendas { get; set; }
    }
}
