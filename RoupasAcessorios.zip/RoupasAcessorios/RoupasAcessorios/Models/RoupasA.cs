﻿namespace RoupasAcessorios.Models
{
    public class RoupasA
    {
        public Guid RoupasAId { get; set; }
        public string Nome { get; set; }
    }
}
