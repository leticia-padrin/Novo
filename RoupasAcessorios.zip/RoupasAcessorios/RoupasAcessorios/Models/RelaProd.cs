﻿using System.ComponentModel;

namespace RoupasAcessorios.Models
{
    public class RelaProd
    {
        public Guid RelaProdId { get; set; }
        public string Nome { get; set; }
        public string Categoria { get; set; }
        public int Quantidade { get; set; }
        [DisplayName("Preço")]
        public decimal Preco { get; set; }
    }
}
