﻿using System.ComponentModel;

namespace RoupasAcessorios.Models
{
    public class RelatMov
    {
        public Guid RelatMovId { get; set; }
        [DisplayName("Nota Fiscal")]
        public int NotaFiscal { get; set; }
        [DisplayName("Data e Hora")]
        public DateTime DataHora { get; set; }

        public int Quantidade { get; set; }
        public string TipoMov { get; set; }
        public Guid ProdutosId { get; set; }
        public Produtos? Produtos { get; set; }

        public string ProdutoNome { get; set; }
    }
}
