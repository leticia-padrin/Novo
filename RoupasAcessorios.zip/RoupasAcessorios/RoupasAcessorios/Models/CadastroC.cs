﻿using System.ComponentModel;

namespace RoupasAcessorios.Models
{
    public class CadastroC
    {
        public Guid CadastroCId { get; set; }
        [DisplayName("Número Nota de compra")]
        public int NumeroVendas { get; set; }
        [DisplayName("Data e Hora")]
        public DateTime DataHora { get; set; }    
       
        public int Quantidade { get; set; }
        [DisplayName("Preço")]
        public decimal Preco { get; set; }

    }
}



