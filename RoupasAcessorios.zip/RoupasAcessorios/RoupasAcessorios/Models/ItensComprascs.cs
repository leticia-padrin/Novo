﻿namespace RoupasAcessorios.Models
{
    public class ItensComprascs
    {
        public Guid ItensComprascsId { get; set; }
        public Guid ProdutosId { get; set; }
        public Produtos? Produtos { get; set; }
        public decimal Preco { get; set; }
        public int Quantidade { get; set; }
        public Guid CadastroCId { get; set; }
        public CadastroC? CadastroC { get; set; }
    }
}
